// const express = require("express");
// const app = express();
// var mongoose = require('mongoose');
// const port = 8080;

// //DB CONNECTION

// mongoose.connect('mongodb://localhost:27017');
// var db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function callback () {
//   console.log("hi");
// });

// app.use((req, res, next) => {
//     res.header("Access-Control-Allow-Origin", "http://localhost:3000");  
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-Width, Content-Type, Accept");
//     next();
//   });

// app.use(express.json());
// app.use('/api', require('./route/request'));




const express = require('express')
const app = express()
const mongoose = require('mongoose');
const port = 8080

// connection for mongoDB
var mongoDB = 'mongodb://localhost:27017/vocab';
mongoose.connect(mongoDB, {useNewUrlParser: true, useUnifiedTopology: true});
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB failed to connect to vocab:'));
db.on('connected', console.log.bind(console,'MongoDB connected to vocab:'));

app.use(express.json())
app.use('/api', require('./route/request'))
//app.get('/', (req, res) => {
//  res.send('Expressive!')
//})



