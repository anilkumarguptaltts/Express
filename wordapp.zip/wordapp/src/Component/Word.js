import React, { Component } from 'react';

class Word extends Component {
    constructor(props)
    {
        super(props);
        this.state =
        {
            error: null,
            isLoaded : false,
            words: []
        }
        
    }


componentDidMout(){
    fetch("http://localhost:8080/api/word")
    .then(res=>res.json())
    .then(
        (data) => {
            this.setState({
                isLoaded:true,
                words:data
            });
        },
    (error) =>{
        this.setState({
            isLoaded:true,
            error
        });
      }    
    )
}

    render() {
        return(
            <ul>
                 <div>{ this.words.map((s) => ((<li>{s.Word}</li>)))}</div>
            </ul>
           
        )
    }
}
export default Word;